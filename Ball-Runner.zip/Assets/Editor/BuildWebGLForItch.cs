#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

public static class BuildWebGLForItch
{
    [MenuItem("Ball Runner 3D/Build WebGL for itch.io")]
    public static void Build()
    {
        const string outputPath = "Build/WebGL";
        string[] scenes = new string[] { "Assets/Scenes/SampleScene.unity" };

        if (!File.Exists(scenes[0]))
        {
            EditorUtility.DisplayDialog("WebGL Build", "SampleScene was not found. Check Assets/Scenes/SampleScene.unity.", "OK");
            return;
        }

        if (!BuildPipeline.IsBuildTargetSupported(BuildTargetGroup.WebGL, BuildTarget.WebGL))
        {
            EditorUtility.DisplayDialog("WebGL module missing", "Install the WebGL Build Support module for this Unity Editor version using Unity Hub, then try again.", "OK");
            return;
        }

        Directory.CreateDirectory(outputPath);

        // Disabled compression avoids server-side Brotli/Gzip header configuration issues.
        PlayerSettings.WebGL.compressionFormat = WebGLCompressionFormat.Disabled;
        PlayerSettings.WebGL.decompressionFallback = false;
        PlayerSettings.productName = "Ball Runner 3D";

        BuildPlayerOptions options = new BuildPlayerOptions
        {
            scenes = scenes,
            locationPathName = outputPath,
            target = BuildTarget.WebGL,
            options = BuildOptions.None
        };

        BuildReport report = BuildPipeline.BuildPlayer(options);
        if (report.summary.result == BuildResult.Succeeded)
        {
            EditorUtility.RevealInFinder(Path.GetFullPath(outputPath));
            EditorUtility.DisplayDialog("WebGL Build Complete", "Build created at: " + Path.GetFullPath(outputPath) + "\n\nZip the CONTENTS of this folder and upload the ZIP to itch.io as an HTML game.", "OK");
        }
        else
        {
            EditorUtility.DisplayDialog("WebGL Build Failed", "Build result: " + report.summary.result + "\nCheck the Unity Console for errors.", "OK");
        }
    }
}
#endif
